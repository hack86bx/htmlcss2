<?php
/* Tester si les champs "nom" et "motdepasse" sont remplis */

/* isset permet de savoir si un champ a été défini, donc si une valeur est donnée (on regarde la valeur de l'attribut name de la balise <input>) */
/* Mais attention, il faut aussi vérifier qu'une valeur a été donnée à chacun de ces champs */

if (isset($_GET['nom']) && isset($_GET['motdepasse']) && $_GET['nom']!="" && $_GET['motdepasse']!="") {
    /* Si oui, alors j'affiche le nom de la personne */    
    echo "<h1>Bienvenue ".$_GET['nom'].", sur mon site !</h1>";
} else {
    /* Sinon, j'affiche "Pas possible" */
    echo "<p>Pas possible d'afficher la réponse</p>";
}

?>